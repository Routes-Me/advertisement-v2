﻿using AdvertisementService.Models.DBModels;


namespace AdvertisementService.Abstraction
{
    public interface IMediaRepository : IGenericRepository<Medias>
    {
    }
}
