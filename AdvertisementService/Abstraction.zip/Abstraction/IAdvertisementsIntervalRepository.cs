﻿using AdvertisementService.Models.DBModels;

namespace AdvertisementService.Abstraction
{
    public interface IAdvertisementsIntervalRepository : IGenericRepository<AdvertisementsIntervals>
    {
    }
}
