﻿using AdvertisementService.Models.DBModels;

namespace AdvertisementService.Abstraction
{
    public interface IAdvertisementRepository : IGenericRepository<Advertisements>
    {
        //bool CheckIntervalExistence(int intervalId);
        //bool CheckCampaignExistence(int campaignId);
        //Interval GetInterval(int id);
        //Campaign GetCampaign(int id);
    }
}
