﻿using AdvertisementService.Models.DBModels;


namespace AdvertisementService.Abstraction
{
    public interface ICampaignRepository : IGenericRepository<Campaigns>
    {

    }
}
