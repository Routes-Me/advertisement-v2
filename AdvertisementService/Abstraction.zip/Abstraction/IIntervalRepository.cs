﻿using AdvertisementService.Models.DBModels;


namespace AdvertisementService.Abstraction
{
    public interface IIntervalRepository : IGenericRepository<Intervals>
    {
    }
}
